apt update && apt upgrade -y && apt autoremove -y && apt autoclean && reboot

# CONFIGURACIÓN MEDIANTE COMANDOS (RECOMENDABLE PARA VER COMO FUNCIONA WIREGUARD PASO A PASO)

# Side to Side

## Comandos Máquina 1

<pre>
root@peer1:~# apt install wireguard -y
Reading package lists... Done
Building dependency tree... Done
Reading state information... Done
wireguard is already the newest version (1.0.20210223-1).
0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.

root@peer1:~# cd /etc/wireguard/

root@peer1:/etc/wireguard# umask 077

root@peer1:/etc/wireguard# wg genkey > private

root@peer1:/etc/wireguard# cat private
yDLJTtvvmuntSIThZgW1yIBuzTdyF2hh6lMgcnEGuV8=

root@peer1:/etc/wireguard# ip link add wg0 type wireguard

root@peer1:/etc/wireguard# ip address add 10.0.150.1/24 dev wg0

root@peer1:/etc/wireguard# wg set wg0 private-key ./private listen-port 51820

root@peer1:/etc/wireguard# ip link set wg0 up

root@peer1:/etc/wireguard# wg
interface: wg0
  public key: 5AGrkuDzNDSJ98AGP1hKWqVkwse3afIgXWNsmF/iJT0=
  private key: (hidden)
  listening port: 51820

root@peer1:/etc/wireguard# ip a
...
3: eth1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:40:a9:39 brd ff:ff:ff:ff:ff:ff
    altname enp0s8
    inet 192.168.0.35/24 brd 192.168.0.255 scope global dynamic eth1
       valid_lft 85730sec preferred_lft 85730sec
    inet6 fe80::a00:27ff:fe40:a939/64 scope link
       valid_lft forever preferred_lft forever
5: wg0: <POINTOPOINT,NOARP,UP,LOWER_UP> mtu 1420 qdisc noqueue state UNKNOWN group default qlen 1000
    link/none
    inet 10.0.150.1/24 scope global wg0
       valid_lft forever preferred_lft forever

root@peer1:/etc/wireguard# wg set wg0 peer t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU= allowed-ips 10.0.150.2/32 endpoint 192.168.0.36:51820

root@peer1:/etc/wireguard# wg
interface: wg0
  public key: 5AGrkuDzNDSJ98AGP1hKWqVkwse3afIgXWNsmF/iJT0=
  private key: (hidden)
  listening port: 51820

peer: t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=
  endpoint: 192.168.0.36:51820
  allowed ips: 10.0.150.2/32

root@peer1:/etc/wireguard# ping 10.0.150.2
PING 10.0.150.2 (10.0.150.2) 56(84) bytes of data.
64 bytes from 10.0.150.2: icmp_seq=1 ttl=64 time=1.09 ms
64 bytes from 10.0.150.2: icmp_seq=2 ttl=64 time=1.48 ms
64 bytes from 10.0.150.2: icmp_seq=3 ttl=64 time=0.712 ms
^C
--- 10.0.150.2 ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 2003ms
rtt min/avg/max/mdev = 0.712/1.091/1.478/0.312 ms
</pre>

--------------------------------------------------------------------------------

## Comandos Máquina 2

<pre>
root@peer2:~# apt install wireguard -y
Reading package lists... Done
Building dependency tree... Done
Reading state information... Done
wireguard is already the newest version (1.0.20210223-1).
0 upgraded, 0 newly installed, 0 to remove and 0 not upgraded.

root@peer2:~# cd /etc/wireguard/

root@peer2:/etc/wireguard# umask 077

root@peer2:/etc/wireguard# wg genkey > private

root@peer2:/etc/wireguard# cat private
0KgXk3JdgrqvpoLXro7B8BvJtATdX4Ml04C/MLZxwGI=

root@peer2:/etc/wireguard# wg pubkey < private
t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=

root@peer2:/etc/wireguard# ip link add wg0 type wireguard

root@peer2:/etc/wireguard# ip address add 10.0.150.2/24 dev wg0

root@peer2:/etc/wireguard# wg set wg0 private-key ./private listen-port 51820

root@peer2:/etc/wireguard# ip link set wg0 up

root@peer2:/etc/wireguard# wg
interface: wg0
  public key: t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=
  private key: (hidden)
  listening port: 51820

root@peer2:/etc/wireguard# ip a
...
3: eth1: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000
    link/ether 08:00:27:ba:36:9d brd ff:ff:ff:ff:ff:ff
    altname enp0s8
    inet 192.168.0.36/24 brd 192.168.0.255 scope global dynamic eth1
       valid_lft 85753sec preferred_lft 85753sec
    inet6 fe80::a00:27ff:feba:369d/64 scope link
       valid_lft forever preferred_lft forever
4: wg0: <POINTOPOINT,NOARP,UP,LOWER_UP> mtu 1420 qdisc noqueue state UNKNOWN group default qlen 1000
    link/none
    inet 10.0.150.2/24 scope global wg0
       valid_lft forever preferred_lft forever

root@peer2:/etc/wireguard# wg
interface: wg0
  public key: t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=
  private key: (hidden)
  listening port: 51820

root@peer2:/etc/wireguard# wg set wg0 peer 5AGrkuDzNDSJ98AGP1hKWqVkwse3afIgXWNsmF/iJT0= allowed-ips 10.0.150.1/32 endpoint 192.168.0.35:51820

root@peer2:/etc/wireguard# wg
interface: wg0
  public key: t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=
  private key: (hidden)
  listening port: 51820

peer: 5AGrkuDzNDSJ98AGP1hKWqVkwse3afIgXWNsmF/iJT0=
  endpoint: 192.168.0.35:51820
  allowed ips: 10.0.150.1/32

root@peer2:/etc/wireguard# ping 10.0.150.1
PING 10.0.150.1 (10.0.150.1) 56(84) bytes of data.
64 bytes from 10.0.150.1: icmp_seq=1 ttl=64 time=2.29 ms
64 bytes from 10.0.150.1: icmp_seq=2 ttl=64 time=0.977 ms
64 bytes from 10.0.150.1: icmp_seq=3 ttl=64 time=0.730 ms
^C
--- 10.0.150.1 ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 2003ms
rtt min/avg/max/mdev = 0.730/1.332/2.289/0.684 ms
</pre>

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

# Peer1

Private: yDLJTtvvmuntSIThZgW1yIBuzTdyF2hh6lMgcnEGuV8=
Public: 5AGrkuDzNDSJ98AGP1hKWqVkwse3afIgXWNsmF/iJT0=

# Peer2

Private: 0KgXk3JdgrqvpoLXro7B8BvJtATdX4Ml04C/MLZxwGI=
Public: t546uJh9q0r1qFazOb6pQPgLfJHzeiXdxDvai3E/cTU=
