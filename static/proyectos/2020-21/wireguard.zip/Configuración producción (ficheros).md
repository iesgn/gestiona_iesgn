apt update && apt upgrade -y && apt autoremove -y && apt autoclean && reboot

# CONFIGURACIÓN MEDIANTE FICHEROS (RECOMENDABLE PARA UN ENTORNO DE PRODUCCIÓN)

## Comandos Servidor

<pre>
root@server:~# apt install wireguard -y

root@server:~# nano /etc/sysctl.conf
...
net.ipv4.ip_forward = 1
...

root@server:~# sysctl -p /etc/sysctl.conf
net.ipv4.ip_forward = 1

root@server:~# cd /etc/wireguard/

root@server:/etc/wireguard# umask 077

root@server:/etc/wireguard# wg genkey | tee serverprivatekey | wg pubkey > serverpublickey

root@server:/etc/wireguard# ls -l
total 8
-rw------- 1 root root 45 May 26 11:09 serverprivatekey
-rw------- 1 root root 45 May 26 11:09 serverpublickey

root@server:/etc/wireguard# cat serverprivatekey
wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=

root@server:/etc/wireguard# cat serverpublickey
cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=

root@server:/etc/wireguard# nano wg0.conf

root@server:/etc/wireguard# cat wg0.conf
# Server config
[Interface]
Address = 10.0.100.1
PrivateKey = wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.1 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

root@server:/etc/wireguard# ip a show wg0
4: wg0: <POINTOPOINT,NOARP,UP,LOWER_UP> mtu 1420 qdisc noqueue state UNKNOWN group default qlen 1000
    link/none
    inet 10.0.100.1/32 scope global wg0
       valid_lft forever preferred_lft forever

root@server:/etc/wireguard# systemctl enable wg-quick@wg0
Created symlink /etc/systemd/system/multi-user.target.wants/wg-quick@wg0.service → /lib/systemd/system/wg-quick@.service.
</pre>

### En este punto el servidor estaría listo a falta de añadir clientes.

--------------------------------------------------------------------------------

## Comandos Cliente Linux

### Esta primera parte se hará en el cliente propiamente ya que vamos a crear su configuración.

<pre>
root@client:~# apt install wireguard -y

root@client:~# cd /etc/wireguard/

root@client:/etc/wireguard# umask 077

root@client:/etc/wireguard# wg genkey | tee clientprivatekey | wg pubkey > clientpublickey

root@client:/etc/wireguard# ls -l
total 8
-rw------- 1 root root 45 May 26 11:12 clientprivatekey
-rw------- 1 root root 45 May 26 11:12 clientpublickey

root@client:/etc/wireguard# cat clientprivatekey
qEFD2evf0hEr/oAWCTReK7BCuRjZ+zeCu45WgSV1QlQ=

root@client:/etc/wireguard# cat clientpublickey
MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=

root@client:/etc/wireguard# nano wg0.conf

root@client:/etc/wireguard# cat wg0.conf
[Interface]
Address = 10.0.100.2/32
PrivateKey = qEFD2evf0hEr/oAWCTReK7BCuRjZ+zeCu45WgSV1QlQ=
ListenPort = 51820

[Peer]
PublicKey = cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
AllowedIPs = 0.0.0.0/0
Endpoint = 192.168.0.49:51820
</pre>

### En este punto nuestro cliente estaría listo para realizar la conexión, pero aún nos faltaría añadir al servidor este nuevo cliente, por lo que vamos a ello.

<pre>
root@server:/etc/wireguard# nano wg0.conf

root@server:/etc/wireguard# cat wg0.conf
# Server config
[Interface]
Address = 10.0.100.1
PrivateKey = wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Clients configs

# Debian Client
[Peer]
Publickey = MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
AllowedIPs = 10.0.100.2/32
PersistentKeepAlive = 25

root@server:/etc/wireguard# wg-quick down wg0
[#] ip link delete dev wg0
[#] iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.1 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] ip -4 route add 10.0.100.2/32 dev wg0
[#] iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  allowed ips: 10.0.100.2/32
  persistent keepalive: every 25 seconds
</pre>

### Ahora sí, el servidor estaría listo y podríamos iniciar la conexión en nuestro cliente.

<pre>
root@client:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.2/32 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] wg set wg0 fwmark 51820
[#] ip -4 route add 0.0.0.0/0 dev wg0 table 51820
[#] ip -4 rule add not fwmark 51820 table 51820
[#] ip -4 rule add table main suppress_prefixlength 0
[#] sysctl -q net.ipv4.conf.all.src_valid_mark=1
[#] nft -f /dev/fd/63

root@client:/etc/wireguard# wg
interface: wg0
  public key: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  private key: (hidden)
  listening port: 51820
  fwmark: 0xca6c

peer: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  endpoint: 192.168.0.49:51820
  allowed ips: 0.0.0.0/0
  latest handshake: 34 seconds ago
  transfer: 156 B received, 260 B sent

root@client:/etc/wireguard# ip a show wg0
4: wg0: <POINTOPOINT,NOARP,UP,LOWER_UP> mtu 1420 qdisc noqueue state UNKNOWN group default qlen 1000
    link/none
    inet 10.0.100.2/32 scope global wg0
       valid_lft forever preferred_lft forever

root@client:/etc/wireguard# ping -c 3 www.google.es
PING www.google.es (172.217.17.3) 56(84) bytes of data.
64 bytes from mad07s09-in-f3.1e100.net (172.217.17.3): icmp_seq=1 ttl=61 time=18.9 ms
64 bytes from mad07s09-in-f3.1e100.net (172.217.17.3): icmp_seq=2 ttl=61 time=20.3 ms
64 bytes from mad07s09-in-f3.1e100.net (172.217.17.3): icmp_seq=3 ttl=61 time=22.0 ms

--- www.google.es ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 2087ms
rtt min/avg/max/mdev = 18.946/20.402/21.957/1.231 ms

root@client:/etc/wireguard# systemctl enable wg-quick@wg0
Created symlink /etc/systemd/system/multi-user.target.wants/wg-quick@wg0.service → /lib/systemd/system/wg-quick@.service.
</pre>

### Vamos a mirar en el servidor si la conexión se ha iniciado y se están produciendo transmisiones de datos.

<pre>
root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:51820
  allowed ips: 10.0.100.2/32
  latest handshake: 1 minute, 22 seconds ago
  transfer: 2.24 KiB received, 2.12 KiB sent
  persistent keepalive: every 25 seconds
</pre>

### Efectivamente el cliente Debian ahora se encuentra en la red y navega por la VPN.

### Vamos a probar a visualizar una web en el cliente.

<pre>
root@client:/etc/wireguard# apt install lynx -y

root@client:/etc/wireguard# lynx www.javierpzh.com
Inicio | Javier Pérez Hidalgo (p1 of 5)
Inicio Categorías Sobre mí

Javier Pérez Hidalgo

Implantación de aplicaciones web PHP en Docker

En este artículo voy a realizar el despliegue de varias aplicaciones web escritas en PHP en
contenedores Docker. Todos los ficheros...

Publicado por Javier Pérez Hidalgo el dom 07 marzo 2021

Despliegue de un cluster de Kubernetes

En este artículo vamos a crear un cluster de Kubernetes (k8s) y para ello he decidido utilizar
la distribución k3s. Posteriormente,...

Publicado por Javier Pérez Hidalgo el sáb 06 marzo 2021

Auditorías de bases de datos

Oracle Vamos a activar las auditorías en nuestro servidor. Por defecto, Oracle incorpora las
-- press space for next page --
Arrow keys: Up and Down to move.  Right to follow a link; Left to go back.
H)elp O)ptions P)rint G)o M)ain screen Q)uit /=search [delete]=history list
</pre>

### El proceso de añadir el cliente habría terminado.

--------------------------------------------------------------------------------

## Comandos Cliente W10

### Esta primera parte se hará en el cliente propiamente ya que vamos a crear su configuración.

imagen: W10-config

### En este punto nuestro cliente estaría listo para realizar la conexión, pero aún nos faltaría añadir al servidor este nuevo cliente Windows, por lo que vamos a ello.

<pre>
root@server:/etc/wireguard# nano wg0.conf

root@server:/etc/wireguard# cat wg0.conf
# Server config
[Interface]
Address = 10.0.100.1
PrivateKey = wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Clients configs

# Debian Client
[Peer]
Publickey = MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
AllowedIPs = 10.0.100.2/32
PersistentKeepAlive = 25

# W10 Client
[Peer]
PublicKey = 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
AllowedIPs = 10.0.100.3/32
PersistentKeepAlive = 25

root@server:/etc/wireguard# wg-quick down wg0
[#] ip link delete dev wg0
[#] iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.1 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] ip -4 route add 10.0.100.3/32 dev wg0
[#] ip -4 route add 10.0.100.2/32 dev wg0
[#] iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:57803
  allowed ips: 10.0.100.2/32
  latest handshake: 6 seconds ago
  transfer: 148 B received, 124 B sent
  persistent keepalive: every 25 seconds

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  allowed ips: 10.0.100.3/32
  persistent keepalive: every 25 seconds
</pre>

### Ahora sí, el servidor estaría listo y podríamos iniciar la conexión en nuestro cliente.

imagen: W10-activate

### Vamos a mirar en el servidor si la conexión se ha iniciado y se están produciendo transmisiones de datos.

<pre>
root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  endpoint: 192.168.0.28:60539
  allowed ips: 10.0.100.3/32
  latest handshake: 2 seconds ago
  transfer: 5.88 KiB received, 8.13 KiB sent
  persistent keepalive: every 25 seconds

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:57803
  allowed ips: 10.0.100.2/32
  latest handshake: 36 seconds ago
  transfer: 292 B received, 236 B sent
  persistent keepalive: every 25 seconds
</pre>

### Efectivamente el cliente Windows ahora se encuentra en la red y navega por la VPN.

imagen: W10-direcciónIP

### Probamos a hacer un ping a internet.

imagen: W10-ping

### El proceso de añadir el cliente Windows habría terminado.

--------------------------------------------------------------------------------

## Comandos Cliente Android

### Todo el proceso se lleva a cabo en el servidor, ya que el cliente Android obtendrá directamente la configuración al escanear un código QR.

### En esta primera parte vamos a crear la configuración del cliente.

<pre>
root@server:/etc/wireguard# mkdir client_android

root@server:/etc/wireguard# cd client_android/

root@server:/etc/wireguard/client_android# umask 077

root@server:/etc/wireguard/client_android# wg genkey | tee clientandroidprivatekey | wg pubkey > clientandroidpublickey

root@server:/etc/wireguard/client_android# ls -l
total 8
-rw------- 1 root root 45 May 26 17:07 clientandroidprivatekey
-rw------- 1 root root 45 May 26 17:07 clientandroidpublickey

root@server:/etc/wireguard/client_android# cat clientandroidprivatekey
qF49LZiAUzPDqMSN5CJja4rH/ljkxOosdycicEa4YkE=

root@server:/etc/wireguard/client_android# cat clientandroidpublickey
MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=

root@server:/etc/wireguard/client_android# nano clientAndroid.conf

root@server:/etc/wireguard/client_android# cat clientAndroid.conf
[Interface]
Address = 10.0.100.4/32
PrivateKey = qF49LZiAUzPDqMSN5CJja4rH/ljkxOosdycicEa4YkE=
ListenPort = 51820

[Peer]
Publickey = cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
AllowedIPs = 0.0.0.0/0
Endpoint = 192.168.0.49:51820

root@server:/etc/wireguard/client_android# apt install qrencode -y

root@server:/etc/wireguard/client_android# qrencode -t ansiutf8 < clientAndroid.conf
█████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████
████ ▄▄▄▄▄ █▀▀█▀▀█▀ █▄  █▄▄█ ▄█▀ ▄  █▄█  ▄▄▀█▀ ▀██ ▄▄▄▄▄ ████
████ █   █ █▀▄▀▄█▀▀▀█▄▄▀▄▀▀█▄█▄█▀  ██▄█▀█▀▄▄▀▀▀▄▀█ █   █ ████
████ █▄▄▄█ █▀▄▄█ ██▀▄   ▄ ▀▀ ▄▄▄ ▀█▄▀  ▀ ▀ ██▄ ███ █▄▄▄█ ████
████▄▄▄▄▄▄▄█▄█ █ ▀▄▀▄█ ▀ █▄▀ █▄█ ▀▄▀ ▀ █ █ ▀▄▀ ▀ █▄▄▄▄▄▄▄████
████▄▄▄▄▄▀▄▄ ▄█▄▄██ █▄▀ ▄▄█▀▄▄▄▄ ▄ ▀█▄▀ ▀▄▀██▄  █▄█▄▀▄▀ ▀████
██████▀ █▀▄▄█▀██ ██ ▀  █▄█▄▀▄▄▀▀▄▄▀▄▀▀██▄▀▄  █ ▀▄ ▄▄  █▀█████
████ ▄▄██ ▄▀█ ▄  █▀▄ ▀█▀▀▄█▀▄█▄▄▀▄▄██ ▀▄▀ ▀█▄▀▄▄▀▄▀█▀▀█▀▀████
████▀   ▀ ▄█▄▄█ ██ ▄█▀█ ████▄▀▀ ▄▄█▄█ ▄▄▀ █ ▀▀ ▄▀█▄▄▄ █ █████
████ ▄ ██▄▄▀▀  █▄██   ██▀▄   █▀ █▀▄ ▄▄▀█▀ ▀ █   ▄▄█  ▄▄█▀████
█████ ▀▀▀ ▄▄██▀█▄█▄██▀▀▀███▄█▄▀ ▄▄ ▀▀▄    █▄█▀ ███▄█▄ ▀▀▀████
████▄█▀██▄▄▄▄  █ █▀▄▀▄ █  ▄█ █▄▀ ▄▄▄▄▀█▄▀ ███ ▄▄▀ ▀ ▀▄██ ████
████▀▀█▀██▄▀█▀█▀▄▄ ▄█▄▄▄█▄▄▀██▀▄█ ▀ ▄█▄ ▄█▀▀▄█▀ ▀ █▄ ▀▄██████
████▀▀ ▄ ▄▄▄ ▄ ▀▀▄▄▄█▀▄  ▄▄▄ ▄▄▄ ▄ ▀█▀█▄▀▄▀▀ █▄▀ ▄▄▄ ▀▄  ████
████▀█▀  █▄█ █ ▀▄▀▄▄▀▀ ██▀██ █▄█ ▀▄█▀▀ ▀ ██▄██▀█ █▄█ ▄▀██████
████▀█ ▄▄▄▄ ▄ ▀▄▀▄▀█▀▀█▄▄█▄█▄     ▄▀▄██▄▀ ▀▀▄█▄▄     ▀█ ▄████
████ ▄█▄▄▄▄▀█ ▄▄▀▀█ ██▄▄▀▄█▄  ▄▄▀ ▄▄█▀██▀▀▄█▄██▄▄▀▀██▀▄█▄████
████▀▀ ▀▄▀▄ ██▀█▀▀█▀██▄█▀▀▄▄▀▄ ▀█▄  ████▀ ▀▀▀█ █▄▄█▄▄█ ▀█████
████▄██  █▄▀▀ ▄▄▀ ▄▀█ ▀██▄█▄██▄▄▀▀█▀ ▄   ▄▀▄█ ▄ ▄ ▄ ▄▄▀█▀████
█████▀█▄█▄▄█▀█▄▀▀▄█ ▀▄▀█▄▀▀ ▀▄▄▀█▄▄▀▄█▀▀▀ ▀██  █████ ▄▄▄▄████
██████▄ ▄▀▄  ▄▄▀▄▄ ▄█ ▀▀█▄█▄ ▀█▄█▄▄█▀▀▀███▄  ▀▀█ █▀ ▄ █▄▄████
████▄█ █▀▀▄▀▄▀▄█ ▄▄▄▀ ▀ ▀▄ █▄▀▀██▄▄ ▄▀▀ ▀▄▀ ▀██▄██▄███▄██████
████▄ ▀▄▄▄▄▄▄ ▄▄▄  ▀█▀▀▄▀██▄████▀▀▀ ▀▄ ▄▄▄█▀ ▀  █▄▄ ▄▄▀██████
███████▄██▄█▀█ ▀█ ▀█  ▀    ▄ ▄▄▄ ▄▄▀▄▀▀▀ ▄▀█▄▄ ▀ ▄▄▄ █▄██████
████ ▄▄▄▄▄ █▄   ▀▄█ ██▀▀██▄▀ █▄█ ▄▄▀▄█▄ ▀ █▄▀█ ▄ █▄█  ▄▄▄████
████ █   █ █ ▄█ ▀█ ▀▄▀█▄   ▄ ▄  ▄▄▄ █▀█▀▀▄█▄▄███  ▄  ▀▄▄█████
████ █▄▄▄█ █ ▀▀███▄▀ █  ██▄▀█  ▀▀█  █▄█▄██ ▄█▀█▀██▄  ▄▀ █████
████▄▄▄▄▄▄▄█▄▄█▄██▄▄███▄█▄███▄█▄█▄▄▄█████▄█▄█▄▄▄▄█▄▄▄████████
█████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████
</pre>

### En nuestro dispositivo Android, nos bastaría con instalar desde "Play Store", la app de Wireguard y elegir como método de configuración, el escaneo de código QR, y directamente nos importará la configuración necesaria.

imagen: Android-nombretun

imagen: Android-config

### Ahora, una vez disponemos de la configuración del cliente Android lista, vamos a añadir al archivo de configuración de nuestro servidor, el nuevo cliente.

<pre>
root@server:/etc/wireguard# nano wg0.conf

root@server:/etc/wireguard# cat wg0.conf
# Server config
[Interface]
Address = 10.0.100.1
PrivateKey = wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Clients configs

# Debian Client
[Peer]
Publickey = MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
AllowedIPs = 10.0.100.2/32
PersistentKeepAlive = 25

# W10 Client
[Peer]
PublicKey = 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
AllowedIPs = 10.0.100.3/32
PersistentKeepAlive = 25

# Android Client
[Peer]
Publickey = MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
AllowedIPs = 10.0.100.4/32
PersistentKeepAlive = 25

root@server:/etc/wireguard# wg-quick down wg0
[#] ip link delete dev wg0
[#] iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.1 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] ip -4 route add 10.0.100.4/32 dev wg0
[#] ip -4 route add 10.0.100.3/32 dev wg0
[#] ip -4 route add 10.0.100.2/32 dev wg0
[#] iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:51820
  allowed ips: 10.0.100.2/32
  latest handshake: 6 seconds ago
  transfer: 436 B received, 380 B sent
  persistent keepalive: every 25 seconds

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  endpoint: 192.168.0.28:51820
  allowed ips: 10.0.100.3/32
  latest handshake: 31 seconds ago
  transfer: 180 B received, 156 B sent
  persistent keepalive: every 25 seconds

peer: MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
  allowed ips: 10.0.100.4/32
  persistent keepalive: every 25 seconds
</pre>

### En este punto ya podríamos iniciar el túnel en el dispositivo Android.

imagen: Android-activetun

### Vamos a mirar en el servidor si la conexión se ha iniciado y se están produciendo transmisiones de datos.

<pre>
root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  endpoint: 192.168.0.28:51820
  allowed ips: 10.0.100.3/32
  latest handshake: 22 seconds ago
  transfer: 6.53 KiB received, 9.01 KiB sent
  persistent keepalive: every 25 seconds

peer: MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
  endpoint: 192.168.0.14:51820
  allowed ips: 10.0.100.4/32
  latest handshake: 34 seconds ago
  transfer: 15.39 KiB received, 42.54 KiB sent
  persistent keepalive: every 25 seconds

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:51820
  allowed ips: 10.0.100.2/32
  latest handshake: 2 minutes, 34 seconds ago
  transfer: 468 B received, 540 B sent
  persistent keepalive: every 25 seconds
</pre>

### Nuestro Android ya estaría navegando a través de nuestra VPN.

--------------------------------------------------------------------------------

## Comandos Cliente iOS (Servidor)

### Todo el proceso se lleva a cabo en el servidor, ya que el cliente iOS, al igual que el Android, obtendrá directamente la configuración al escanear un código QR.

### En esta primera parte vamos a crear la configuración del cliente.

<pre>
root@server:/etc/wireguard# mkdir client_iOS

root@server:/etc/wireguard# cd client_iOS/

root@server:/etc/wireguard/client_iOS# umask 077

root@server:/etc/wireguard/client_iOS# wg genkey | tee clientiOSprivatekey | wg pubkey > clientiOSpublickey

root@server:/etc/wireguard/client_iOS# ls -l
total 8
-rw------- 1 root root 45 May 26 18:04 clientiOSprivatekey
-rw------- 1 root root 45 May 26 18:04 clientiOSpublickey

root@server:/etc/wireguard/client_iOS# cat clientiOSprivatekey
kEmpljarBs76OA9woqrX/wzKzgVn7jWIAvABblkbzmU=

root@server:/etc/wireguard/client_iOS# cat clientiOSpublickey
539i52F6p08kK/wKkNW5Wi20fTQWigpJbXfoWNZASks=

root@server:/etc/wireguard/client_iOS# nano clientiOS.conf

root@server:/etc/wireguard/client_iOS# cat clientiOS.conf
[Interface]
Address = 10.0.100.5/32
PrivateKey = kEmpljarBs76OA9woqrX/wzKzgVn7jWIAvABblkbzmU=
ListenPort = 51820
DNS = 8.8.8.8

[Peer]
Publickey = cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
AllowedIPs = 0.0.0.0/0
Endpoint = 192.168.0.49:51820

root@server:/etc/wireguard/client_iOS# apt install qrencode -y

root@server:/etc/wireguard/client_iOS# qrencode -t ansiutf8 < clientiOS.conf
█████████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████████
████ ▄▄▄▄▄ █ ▄▄▀  ▀ ▀▄█▀▄█▄  ▀▄█▀▀▄   █▀█   ▀▄▄ ▀█▄ ██ ▄▄▄▄▄ ████
████ █   █ █ ▀▀▀▄▀▄▀  █▀█  ▀█▄      ▄█▀▀▀▄██ █▀ ▄▄▄ ██ █   █ ████
████ █▄▄▄█ █▀ ▄▄ ▀ ▄ ▀▄▄  ▄▄██ ▄▄▄ ▀▄ ▀█▄█▄▄█  ▀▀▄▀▄██ █▄▄▄█ ████
████▄▄▄▄▄▄▄█▄█ ▀ █▄█▄▀▄█▄▀▄█ █ █▄█ █ ▀ █▄▀ █▄█▄▀ █ ▀▄█▄▄▄▄▄▄▄████
████  ▀█▄▄▄▀███  █▄ █▄▄▄▀▄▀  ▄ ▄▄   ▀ ▀█ █▀█▄█ ▀▄ █  █▀▄▀▄▄▄▄████
████ █ ▄ ▀▄▀▄ ▄ ▀▀█▀▄▀ ▄█▄ █▀ █ ▄ ▄██▄ ▀ █▄▀▀ ▄▄  █  █  ██▄██████
█████ ██▀ ▄█▄█   ▄  ▄▄▀▀▀▀██▀▀█ ▀█ █▄██▄▄   ▀▄▀▀▄▀▄█ █▀▄▀█▄▄▄████
████▄█▀▀▀█▄ ▀ ▄ ▀▀▀█ ▄▀▀ █▀█▀▀▄▄▀▄██    ▀█ ▄▄▄ ▄▀▄ █▀▀  ▄ █▄█████
█████ ▀█▀ ▄▀▀█▄▄  ▄ ▄▀▄▄  ▀▀  ▄▀█▀▀▄ ▀█  ▄▀▀█▀ ▀▄ ▄▀  ▀██▀▀▄ ████
█████  █  ▄ ▄▀▀██▄ ▀▄  █▄ ▀▀ ██▄▄▄▄▄ ▄▀▀██▀▀   ▀▀     ▄ ▄██▄▀████
████▄ ▀▄▀▄▄   ▀▄█▀▀▄██ ▄▄█▀▄  ▀▀█▄ ▀▄ ██▄▄▀ ██ █  ▄█▀▄▀ ▀█▀▄ ████
████▄▄▄▀▀█▄█▀ ▀▀▀▀▀▀ ▀▄▀ ▀▀▀█▄█▄██▄▀██ ██▄█▀ ▀▄▄▀▄██▀▀▄▄▄ █ █████
████ ▄█▄▄▄▄▄▀▄▀█▀▄▀▀█▄▄▄ ▄▀▀▀▀▄█▀█▀  ▀█▀▄▀▀ ██ █ ▀▄▀▀█▀ ▀██▀▄████
████ ▄▀▄ ▄▄▄  █▄▄▀▀▄ ▄██ ▀██▄▀ ▄▄▄ █▀▀ ▄▀█ ▀ ▀▄█  ▀█ ▄▄▄ ██▀█████
█████▄▄▄ █▄█ ▀▀▄▀▀█▀▄▀  ▀▄▄▄▀  █▄█ ▀▄█▀   ▀ ██ █▄ █▄ █▄█ ▀██▀████
█████ █▄▄▄▄  █▀▄  ▀█ █▀█▀   █▄▄  ▄  ▀██  ▀▀▄▀▀ ▄█ █▀  ▄ ▄█▄▄▀████
████▀██▄█▀▄▄▄▀██ █▄▄▄▀▄█▀▄▀▀▀ ▀▀█▄█   ▄▄ ▄  █ ▀█  ████  ▄▄▀▄█████
█████   ██▄▄ ▀█▄▄ ▀▀   ▄█▀█ █▀▄█ ▀▄▀▀▀▀▀█▀▄█▀ ▄█▀▄  █ ▀█ ▄▄ █████
████▀▀▄▄ ▄▄ █ ▄█ ▀▄▀▀  ▀ ▀▀▀▄▀▄▀▀▀ ▀ ▀██▀▀▀▀▄  ▀▄ ▄█   ▄▄▀█▄ ████
█████ ▀ ▄▀▄ ▄▀█   █▄██ ▄██▀▄ ▀▄▄██▀██▀█▄ ▄▄█▀█ █▀▄ ▄▄█▀▄█ ▄██████
████▀▀▄█▄█▄██▄▀▀▄▄ ▀▄ ▄  ▄▀ ▀█▀▄▄▀   █ ▀█▄█▀ ▄ █▄▀██ ▄ ▀▄ █▄▄████
████▀▄ █▄▄▄▀▀ ▀ ▄▄██ ▀  ▀▄ █▄█▄█▀▄▀█▀▄▄▄  ██ ▄ ▄▄█▀▄▄▄▀▀▄▄▄██████
████  █▄██▄ ▀█ ▀▀ █▀▄▄▀▀▀▀██▀  ▄▄  ▀ █▄▄ ▀▄ ▀▄ ▀▄▀█▀▄▀▄▀█ ▀  ████
████ ▀ ▀▀▄▄▀▄▄█▀▄▄▄  ▀▀▀ ▀▀▀▄ ▀ ▄▄▀█   █▀█  █ ▄▄█ ▀█▀▄▀ ██▄▀█████
██████████▄▄ ▄▄ █ ▀▀█▄ ▄▀▄▀█▀█ ▄▄▄   ▀▄ ▄█ ▄▀▀▀▀▄ █▀ ▄▄▄  ███████
████ ▄▄▄▄▄ █▀█ █▄▀▀██▄ █  ▀█▀█ █▄█  █▀█ ▀ ▄▄▀▀  ▀▀█▀ █▄█ ▄█ ▀████
████ █   █ █▄▄ ▀█▀ ▄█  ▄▄█▀▄ █ ▄ ▄ ▀▄▀▄█▀█▀███ ▀ █▄▀▄ ▄▄ █▀▀▀████
████ █▄▄▄█ █▀▄▄█ ▄▀▀ █▀▀ ▄█▀█▄ ▀ ▀██▄▀▀ █ ▀ ▄ ▄▄▀▀▀▄▀▄█▀  ███████
████▄▄▄▄▄▄▄█▄▄▄█▄███▄▄▄████▄▄█▄▄█▄▄█▄█████▄███▄█▄██▄█▄█▄████▄████
█████████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████████
</pre>

### En nuestro dispositivo iOS, nos bastaría con instalar desde "App Store", la app de Wireguard y elegir como método de configuración, el escaneo de código QR, y directamente nos importara la configuración necesaria.

video: iOS-config

### Ahora, una vez disponemos de la configuración del cliente iOS lista, vamos a añadir al archivo de configuración de nuestro servidor, el nuevo cliente.

<pre>
root@server:/etc/wireguard# nano wg0.conf

root@server:/etc/wireguard# cat wg0.conf
# Server config
[Interface]
Address = 10.0.100.1
PrivateKey = wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
ListenPort = 51820
PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE
PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

# Clients configs

# Debian Client
[Peer]
Publickey = MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
AllowedIPs = 10.0.100.2/32
PersistentKeepAlive = 25

# W10 Client
[Peer]
PublicKey = 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
AllowedIPs = 10.0.100.3/32
PersistentKeepAlive = 25

# Android Client
[Peer]
Publickey = MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
AllowedIPs = 10.0.100.4/32
PersistentKeepAlive = 25

# iOS Client
[Peer]
Publickey = 539i52F6p08kK/wKkNW5Wi20fTQWigpJbXfoWNZASks=
AllowedIPs = 10.0.100.5/32
PersistentKeepAlive = 25

root@server:/etc/wireguard# wg-quick down wg0
[#] ip link delete dev wg0
[#] iptables -D FORWARD -i wg0 -j ACCEPT; iptables -D FORWARD -o wg0 -j ACCEPT; iptables -t nat -D POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg-quick up wg0
[#] ip link add wg0 type wireguard
[#] wg setconf wg0 /dev/fd/63
[#] ip -4 address add 10.0.100.1 dev wg0
[#] ip link set mtu 1420 up dev wg0
[#] ip -4 route add 10.0.100.5/32 dev wg0
[#] ip -4 route add 10.0.100.4/32 dev wg0
[#] ip -4 route add 10.0.100.3/32 dev wg0
[#] ip -4 route add 10.0.100.2/32 dev wg0
[#] iptables -A FORWARD -i wg0 -j ACCEPT; iptables -A FORWARD -o wg0 -j ACCEPT; iptables -t nat -A POSTROUTING -o eth0 -j MASQUERADE

root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
  endpoint: 192.168.0.14:51820
  allowed ips: 10.0.100.4/32
  latest handshake: 16 seconds ago
  transfer: 51.44 KiB received, 267.32 KiB sent
  persistent keepalive: every 25 seconds

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  endpoint: 192.168.0.28:51820
  allowed ips: 10.0.100.3/32
  latest handshake: 27 seconds ago
  transfer: 372 B received, 316 B sent
  persistent keepalive: every 25 seconds

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:51820
  allowed ips: 10.0.100.2/32
  latest handshake: 1 minute, 20 seconds ago
  transfer: 916 B received, 892 B sent
  persistent keepalive: every 25 seconds

peer: 539i52F6p08kK/wKkNW5Wi20fTQWigpJbXfoWNZASks=
  allowed ips: 10.0.100.5/32
  persistent keepalive: every 25 seconds
</pre>

### En este punto ya podríamos iniciar el túnel en el dispositivo iOS.

video: iOS-activetun

### Vamos a mirar en el servidor si la conexión se ha iniciado y se están produciendo transmisiones de datos.

<pre>
root@server:/etc/wireguard# wg
interface: wg0
  public key: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=
  private key: (hidden)
  listening port: 51820

peer: 539i52F6p08kK/wKkNW5Wi20fTQWigpJbXfoWNZASks=
  endpoint: 192.168.0.11:51820
  allowed ips: 10.0.100.5/32
  latest handshake: 3 seconds ago
  transfer: 162.86 MiB received, 24.45 MiB sent
  persistent keepalive: every 25 seconds

peer: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=
  endpoint: 192.168.0.28:51820
  allowed ips: 10.0.100.3/32
  latest handshake: 26 seconds ago
  transfer: 31.86 KiB received, 56.32 KiB sent
  persistent keepalive: every 25 seconds

peer: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=
  endpoint: 192.168.0.50:51820
  allowed ips: 10.0.100.2/32
  latest handshake: 32 seconds ago
  transfer: 3.21 KiB received, 4.53 KiB sent
  persistent keepalive: every 25 seconds

peer: MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=
  endpoint: 192.168.0.14:51820
  allowed ips: 10.0.100.4/32
  latest handshake: 57 seconds ago
  transfer: 88.71 KiB received, 753.00 KiB sent
  persistent keepalive: every 25 seconds
</pre>

### Nuestro iOS ya estaría navegando a través de nuestra VPN.

video: iOS-music

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

# Pings desde Server

<pre>
root@server:/etc/wireguard# ping -c 1 10.0.100.2
PING 10.0.100.2 (10.0.100.2) 56(84) bytes of data.
64 bytes from 10.0.100.2: icmp_seq=1 ttl=64 time=1.19 ms

--- 10.0.100.2 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 1.191/1.191/1.191/0.000 ms

root@server:/etc/wireguard# ping -c 1 10.0.100.3
PING 10.0.100.3 (10.0.100.3) 56(84) bytes of data.
64 bytes from 10.0.100.3: icmp_seq=1 ttl=128 time=93.0 ms

--- 10.0.100.3 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 93.003/93.003/93.003/0.000 ms

root@server:/etc/wireguard# ping -c 1 10.0.100.4
PING 10.0.100.4 (10.0.100.4) 56(84) bytes of data.
64 bytes from 10.0.100.4: icmp_seq=1 ttl=64 time=353 ms

--- 10.0.100.4 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 352.588/352.588/352.588/0.000 ms

root@server:/etc/wireguard# ping -c 1 10.0.100.5
PING 10.0.100.5 (10.0.100.5) 56(84) bytes of data.
64 bytes from 10.0.100.5: icmp_seq=1 ttl=64 time=296 ms

--- 10.0.100.5 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 295.832/295.832/295.832/0.000 ms
</pre>

# Pings desde Debian Client

<pre>
root@client:/etc/wireguard# ping -c 1 10.0.100.1
PING 10.0.100.1 (10.0.100.1) 56(84) bytes of data.
64 bytes from 10.0.100.1: icmp_seq=1 ttl=64 time=1.68 ms

--- 10.0.100.1 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 1.681/1.681/1.681/0.000 ms

root@client:/etc/wireguard# ping -c 1 10.0.100.3
PING 10.0.100.3 (10.0.100.3) 56(84) bytes of data.
64 bytes from 10.0.100.3: icmp_seq=1 ttl=127 time=137 ms

--- 10.0.100.3 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 136.788/136.788/136.788/0.000 ms

root@client:/etc/wireguard# ping -c 1 10.0.100.4
PING 10.0.100.4 (10.0.100.4) 56(84) bytes of data.
64 bytes from 10.0.100.4: icmp_seq=1 ttl=63 time=93.2 ms

--- 10.0.100.4 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 93.220/93.220/93.220/0.000 ms

root@client:/etc/wireguard# ping -c 1 10.0.100.5
PING 10.0.100.5 (10.0.100.5) 56(84) bytes of data.
64 bytes from 10.0.100.5: icmp_seq=1 ttl=63 time=235 ms

--- 10.0.100.5 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 234.789/234.789/234.789/0.000 ms
</pre>

--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------

# Server Passwords

Private: wOENVR47BOYbfHFUUiYLq2H3xKOSZAe0oNNUXoHXVGk=
Public: cgJ6GfgX1x+YCDzW7TyrmuPzxfkJf5798h+NWwmVlmk=

# Client Passwords - Debian

Private: qEFD2evf0hEr/oAWCTReK7BCuRjZ+zeCu45WgSV1QlQ=
Public: MVD+I0Q7Y4F8dZK6Nl5Lx7C5IDIv1h+Olnf9dBmJNns=

# Client Passwords - W10

Private: cPUkb7hVIyaF+CNjrZOrIT9xK9tesKpRL9Aab5r4y1M=
Public: 7HopGKOY2C8f6jBfEkc8whKUSoNSDvsqgI0ZMzPQ8Bg=

# Client Passwords - Android

Private: qF49LZiAUzPDqMSN5CJja4rH/ljkxOosdycicEa4YkE=
Public: MWNcn3OkGswxkQslf5MfImbidehNL8K/FnEHmTbnglE=

# Client Passwords - iOS

Private: kEmpljarBs76OA9woqrX/wzKzgVn7jWIAvABblkbzmU=
Public: 539i52F6p08kK/wKkNW5Wi20fTQWigpJbXfoWNZASks=
